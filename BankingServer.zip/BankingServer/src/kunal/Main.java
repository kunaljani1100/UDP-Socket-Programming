package kunal;

/**
 * Created by kunal on 22-10-2017.
 */
public class Main {
    public static void main(String []args)
    {
        MultipleThreads multipleThreads=new MultipleThreads();
        multipleThreads.runMultipleThreads();
    }
}
